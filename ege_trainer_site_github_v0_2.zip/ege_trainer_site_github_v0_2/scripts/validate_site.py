#!/usr/bin/env python3
"""Validate the static EGE trainer website before deployment."""
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = ("index.html", "styles.css", "app.js", "tasks_data.json", "manifest.webmanifest", "sw.js", "favicon.svg", ".nojekyll")

def main() -> int:
    missing = [name for name in REQUIRED if not (ROOT / name).is_file()]
    if missing:
        raise SystemExit("Missing website files: " + ", ".join(missing))
    tasks = json.loads((ROOT / "tasks_data.json").read_text(encoding="utf-8"))
    basic = [t for t in tasks if t.get("subjectId") == "math_basic"]
    ids = [t.get("externalId") for t in tasks]
    if len(ids) != len(set(ids)):
        raise SystemExit("Task externalId values must be unique")
    numbers = sorted(t.get("taskNumber") for t in basic)
    if numbers != list(range(1, 22)):
        raise SystemExit(f"Expected basic math tasks 1..21; found: {numbers}")
    for task in basic:
        for field in ("externalId", "title", "statement", "explanation", "correctAnswer"):
            if field not in task or task[field] is None or (isinstance(task[field], str) and not task[field].strip()):
                raise SystemExit(f"Task {task.get('externalId')} has missing field: {field}")
    manifest = json.loads((ROOT / "manifest.webmanifest").read_text(encoding="utf-8"))
    if manifest.get("lang") != "ru-RU" or manifest.get("start_url") != "./":
        raise SystemExit("PWA manifest metadata is not configured as expected")
    print(f"OK: website files present; {len(basic)} basic-math tasks; task IDs unique; PWA manifest valid.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
